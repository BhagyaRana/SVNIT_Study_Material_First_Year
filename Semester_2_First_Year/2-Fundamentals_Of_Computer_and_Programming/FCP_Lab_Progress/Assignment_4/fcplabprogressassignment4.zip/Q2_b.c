#include<stdio.h>

void main()
 {
 	int row,column;
 	int space,star;
 	int n,k=1;
 	printf("Enter the Number of Rows to be Printed : ");
 	scanf("%d",&n);
 	for(row=0;row<=n;row++)
 	 {  

	    for(star=1;star<=n-row;star++)
		 { 
		   printf("%d",k);
		   k++;
		 }
		k=1;
		printf("\n"); 

	 }
 }
