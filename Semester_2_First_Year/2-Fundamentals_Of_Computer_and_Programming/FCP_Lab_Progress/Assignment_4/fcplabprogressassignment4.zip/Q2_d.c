#include<stdio.h>

void main()
 {
 	int row,column;
 	int space,star;
 	int n,i,j;
 	printf("Enter the Number of Rows to be Printed : ");
 	scanf("%d",&n);
    
  
 }
