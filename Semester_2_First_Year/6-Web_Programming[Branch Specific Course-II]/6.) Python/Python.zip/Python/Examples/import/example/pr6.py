'''
Define a function that can accept two strings as input and concatenate them and then print it in console.
Hints:
Use + to concatenate the strings

Solution
'''
def printValue(s1,s2):
	print(s1+s2)

printValue("3","4")
printValue("3","Children") 
printValue(3,"Children") 


def printValue(s1,s2):
	print(s1,s2)

printValue("3","4")
printValue(3,"Children")

