import greeting
greeting.greeting("Jasmina")