import calculation            #Importing calculation module
print(calculation.add(1,2))   #Calling function defined in add module.