import random

print(random.randrange(1,10))

print("---------")

for i in range(5):
    print(random.randint(1, 25))




# Aliasing Modules

# import random as r

# for i in range(5):
#     print(r.randint(1, 25))




#Using from … import

# from random import randint

# for i in range(5):
#     print(randint(1, 25))




# Aliasing Modules

# from random import randint as r

# for i in range(5):
#     print(r(1, 25))

