# Program to show the use of lambda functions

#Create a lambda function that takes one parameter (a) and returns it.
x = lambda  a : a


double = lambda x: x * 2

print(double(5))



adder = lambda x, y: x + y
print (adder (1, 2))



f = lambda x,y : x**2 + y**2
print(f(2,3))
